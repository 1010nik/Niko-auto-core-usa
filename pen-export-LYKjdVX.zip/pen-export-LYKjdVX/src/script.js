let users = [
    { username: 'Nikotexas', password: 'Niko1234', role: 'user' }, // Default user
    { username: 'Admin', password: 'Admin1234', role: 'admin' }    // Default admin
];

let currentUser = null;
let workbookData = [];  // This will hold the data from the uploaded XLS file

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        currentUser = user;
        document.getElementById('login-container').style.display = 'none';

        if (user.role === 'admin') {
            document.getElementById('admin-container').style.display = 'block';
            loadUserList();
        } else {
            document.getElementById('main-container').style.display = 'block';
        }
    } else {
        document.getElementById('login-error').textContent = 'Incorrect username or password';
    }
}

function logout() {
    // Hide all containers and show the login container
    document.getElementById('main-container').style.display = 'none';
    document.getElementById('admin-container').style.display = 'none';
    document.getElementById('login-container').style.display = 'block';

    // Clear any data that might be sensitive
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('search-query').value = '';
    document.getElementById('search-results').innerHTML = '';

    workbookData = []; // Clear the uploaded data
    currentUser = null; // Clear the current user
}

function addUser() {
    const username = document.getElementById('new-user-username').value;
    const password = document.getElementById('new-user-password').value;

    if (username && password) {
        users.push({ username, password, role: 'user' });
        loadUserList();
        alert('User added successfully!');
    } else {
        alert('Please enter both username and password');
    }
}

function loadUserList() {
    const userListContainer = document.getElementById('user-list');
    userListContainer.innerHTML = '';

    users.forEach(user => {
        if (user.role === 'user') {
            const userDiv = document.createElement('div');
            userDiv.textContent = `${user.username}`;
            userListContainer.appendChild(userDiv);
        }
    });
}

// Handle XLS file upload
document.getElementById('price-list-upload').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });

            workbookData = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);
            alert('Price list uploaded successfully!');
        };
        reader.readAsArrayBuffer(file);
    }
});

// Search functionality
function search() {
    const query = document.getElementById('search-query').value.toLowerCase();
    const results = workbookData.filter(item => {
        return Object.values(item).some(val => 
            String(val).toLowerCase().includes(query)
        );
    });

    displayResults(results);
}

function displayResults(results) {
    const resultsContainer = document.getElementById('search-results');
    resultsContainer.innerHTML = '';

    if (results.length === 0) {
        resultsContainer.textContent = 'No results found.';
        return;
    }

    const table = document.createElement('table');
    const headerRow = document.createElement('tr');

    // Create table headers
    Object.keys(results[0]).forEach(key => {
        const th = document.createElement('th');
        th.textContent = key;
        headerRow.appendChild(th);
    });
    table.appendChild(headerRow);

    // Create table rows
    results.forEach(item => {
        const row = document.createElement('tr');
        Object.values(item).forEach(val => {
            const td = document.createElement('td');
            td.textContent = val;
            row.appendChild(td);
        });
        table.appendChild(row);
    });

    resultsContainer.appendChild(table);
}